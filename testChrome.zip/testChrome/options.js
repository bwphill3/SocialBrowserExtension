  let page = document.getElementById('buttonDiv');
  
  const kButtonColors = ['#3aa757', '#e8453c', '#f9bb2d', '#4688f1'];
  var stringReturned;
  
  function constructOptions(kButtonColors) {
    for (let item of kButtonColors) {
      let button = document.createElement('button');
      button.style.backgroundColor = item;
      button.addEventListener('click', 
	  function() 
	  {
		 
		  
		  
		  
		  
		 
		  
		  
		  
		fetch('https://jsonplaceholder.typicode.com/posts', {
		method: 'POST',
		body: JSON.stringify({
		  user: 'foo',
		  body: 'bar',
		  userId: 1
		}),
		headers: {
		  "Content-type": "application/json; charset=UTF-8"
		}
	  })
	  .then(response => response.json())
	  .then(json => stringReturned = json)
	  .then(json => console.log(stringReturned))	  
	  });
 
	  
	  
	  
      page.appendChild(button);
    }
  }
  constructOptions(kButtonColors);
  

  