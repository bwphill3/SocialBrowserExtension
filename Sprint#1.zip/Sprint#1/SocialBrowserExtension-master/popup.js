//javascript must be in separate file for chrome to allow it
//onclicks must be in here and not in the html file


var url = null;

//UNCOMMENT WHEN UPLOADING TO CHROME.
//This works in chrome but not browser debugging because it is specific to extensions.  Gets current tab
//When browser debugging it just returns null for url
/*chrome.tabs.query({'active': true, 'lastFocusedWindow': true}, function (tabs) {
    url = tabs[0].url;
}); */

//displays keyword form
function keyword() {
    document.getElementById("keyword_text").style.display = "list-item";
}

document.getElementById("like_button").onclick = keyword;

//displays url and keyword together
function submit_key() {
setTimeout(function()
{
    var keyword = document.getElementById("keyword").value;
	
	var stringToDisplay = "Similar websites are: " // Begins the string of URLS to display
	

    document.getElementById("keyword_text").style.display = "none";
	
	
					
	var xhr = new XMLHttpRequest();
		xhr.open("POST", 'http://localhost:59279/WebService.asmx/getSimilarWebsites', true);

		//Send the proper header information along with the request
		xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

		xhr.onreadystatechange = function() // This executes when response is gotten
		{
		
		
		
		
			if(this.readyState == XMLHttpRequest.DONE && this.status == 200) 
			{		
					var result = JSON.parse(xhr.response);
					console.log(xhr.response);
					console.log(result);
									

					//document.getElementById("result").innerHTML = "Similar websites are:  " + result;
					
						for ( website in result)
						{
						stringToDisplay = stringToDisplay + JSON.stringify(result[website]['SimilarID']) + " , ";
						console.log("printing:" + JSON.stringify(result[website]['SimilarID']));
						}
						document.getElementById("result").innerHTML = stringToDisplay.replace(/"/g,'');
						
						//document.getElementById("result").innerHTML = "Similar websites are:  " + JSON.stringify(result[website]['WebsiteName']);
						
						//document.getElementById("result").innerHTML = "Similar websites are:  " + JSON.stringify(result);

						
			}
			
		}
		
		xhr.send("id=" + keyword); // What to send, happends after above for some reason
	

    //document.getElementById("result").innerHTML = "Similar websites are:  " + result;
		

    document.getElementById("submit_test").style.display = "block";
	

}, 500);
}

document.getElementById("key_button").onclick = submit_key;

