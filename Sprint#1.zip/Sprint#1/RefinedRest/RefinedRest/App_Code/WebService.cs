﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;

/// <summary>
/// Summary description for WebService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
[System.Web.Script.Services.ScriptService]
public class WebService : System.Web.Services.WebService
{

    public WebService()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    DataClassesDataContext dc = new DataClassesDataContext();

    [WebMethod]
    public string HelloWorld()
    {
        return "Hello World";
    }

    [WebMethod]
    public void getSimilarWebsites(string id)
    {

        var website = from t1 in dc.websiteRelationships
                      where t1.WebsiteName == id
                      select new { t1.SimilarName};


        JavaScriptSerializer jss = new JavaScriptSerializer();

        string json = jss.Serialize(website);


        string strCallback = Context.Request.QueryString["callback"]; // Get callback method name. e.g. jQuery17019982320107502116_1378635607531
        json = strCallback + "" + json + ""; // e.g. jQuery17019982320107502116_1378635607531(....)

        Context.Response.Clear();
        Context.Response.ContentType = "application/json";
        Context.Response.AddHeader("content-length", json.Length.ToString());
        Context.Response.Flush();

        Context.Response.Write(json);

        //return json;
    }

    [WebMethod]
    public void addNewWebsite(string id)
    {
        websitesLiked newWeb = new websitesLiked();
        newWeb.WebsiteName = id;

        dc.websitesLikeds.InsertOnSubmit(newWeb);
        dc.SubmitChanges();
    }

    [WebMethod]
    public void addNewRelationShip(string rootName, string similar)
    {
        websiteRelationship newRel = new websiteRelationship();
        newRel.WebsiteName = rootName;
        newRel.SimilarName = similar;

        dc.websiteRelationships.InsertOnSubmit(newRel);
        dc.SubmitChanges();
    }

}
